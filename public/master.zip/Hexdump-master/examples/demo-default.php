<?php

require_once 'Hexdump.php';

$data = 'Metashock Hexdump';

// display with default settings
hexdump($data);

?>
